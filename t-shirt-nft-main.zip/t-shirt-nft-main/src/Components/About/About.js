import React from "react";
import Image from "../../Assets/AboutImg.png";
import TextImg from "../../Assets/text.png";

export default function About() {
  return (
    <div className="container p-5" Style={"background-color:#568D84;"}>
      <div className="row">
        <div className="col-12 col-md-6 flex-column-reverse flex-md-row">
          <p className="fs-1 fw-bold">THE STORY</p>
          <p className="fs-6 mt-5 fw-bold">
            Alien are now writing their own history where the future is Alien.
            This collection is a modern take inspired by all the Alien who
            rebelled against society's demands, tore up every fucking label or
            stuck the middle finger up to anyone who told them to "smile".
            <br /> <br />
            Through the Alien Society initiative, we hope to help other Alien
            artists bring their art to the world through the blockchain path.
            <br /> <br />
            Part of the funds collected from the sale of the first collection
            will be allocated to sponsoring upcoming new Alien artists who stand
            out with their talent but can't afford to launch a collection due to
            the costs involved. ‍ <br /> <br /> The artists will be pre-selected
            with the help from the Alien Society NFT holders and the Alien
            Society team.
          </p>
          <div className=" mt-2">
            <div className="pt-3">
              <img width="100%" height="150px" src={TextImg} />
            </div>
          </div>
        </div>
        <div className="col-12 col-md-6 d-flex justify-content-center pt-5">
          <img src={Image} width="100%" height="510px" />
        </div>
      </div>
    </div>
  );
}
