import React from "react";

export default function Video() {
  return (
    <div className="container bg-dark p-5" height="400px">
      <div className="row m-6">
        <iframe
          width="420"
          height="315"
          src="https://www.youtube.com/embed/wQVmHLuCnok"
          frameborder="0"
          allowfullscreen
        ></iframe>
      </div>
    </div>
  );
}
