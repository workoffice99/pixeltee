import React from "react";

export default function Text() {
  return (
    <div className="container">
      <div className="row">
        <p className="text-center fs-7 fw-bold">
          Alien Society is a NFT limited edition collection of 5000 alien
          characters created from hand-drawn elements in celebration of all
          inspiring badass Alien and stored as ERC-721 tokens on the Ethereum
          blockchain. <br /> <br />
          By owning a Alien Society NFT you will have access to exclusive
          members only perks like giveaways, voting rights, future drops and
          collabs.
        </p>
      </div>
    </div>
  );
}
